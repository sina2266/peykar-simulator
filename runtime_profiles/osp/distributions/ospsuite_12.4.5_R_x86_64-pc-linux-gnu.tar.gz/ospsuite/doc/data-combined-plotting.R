## ----include = FALSE----------------------------------------------------------
# Load the shared runtime gate; see vignettes/_setup.R.
source("_setup.R")
knitr::opts_chunk$set(
  eval = .ospRuntimeAvailable,
  collapse = TRUE,
  warning = FALSE,
  message = FALSE,
  comment = "#>",
  out.width = "100%",
  fig.height = 6,
  fig.width = 8,
  fig.showtext = TRUE
)

## -----------------------------------------------------------------------------
library(ospsuite)

# simulated data
simFilePath <- system.file("extdata", "Aciclovir.pkml", package = "ospsuite")
sim <- loadSimulation(simFilePath)
simResults <- runSimulations(sim)[[1]]
outputPath <- "Organism|PeripheralVenousBlood|Aciclovir|Plasma (Peripheral Venous Blood)"

# observed data
obsData <- lapply(
  c("ObsDataAciclovir_1.pkml", "ObsDataAciclovir_2.pkml", "ObsDataAciclovir_3.pkml"),
  function(x) loadDataSetFromPKML(system.file("extdata", x, package = "ospsuite"))
)
names(obsData) <- lapply(obsData, function(x) x$name)

myDataCombined <- DataCombined$new()

myDataCombined$addSimulationResults(
  simulationResults = simResults,
  quantitiesOrPaths = outputPath,
  groups = "Aciclovir PVB"
)

myDataCombined$addDataSets(
  obsData$`Vergin 1995.Iv`,
  groups = "Aciclovir PVB"
)

## -----------------------------------------------------------------------------
plotIndividualTimeProfile(myDataCombined)

## -----------------------------------------------------------------------------
plotObservedVsSimulated(myDataCombined)

## -----------------------------------------------------------------------------
plotObservedVsSimulated(myDataCombined, foldDistance = c(1.3, 2))

## -----------------------------------------------------------------------------
plotResidualsVsSimulated(myDataCombined)

## -----------------------------------------------------------------------------
plotResidualsVsTime(myDataCombined)

## -----------------------------------------------------------------------------
plotResidualsVsTime(myDataCombined, scaling = "log")

## -----------------------------------------------------------------------------
myPlotConfiguration <- DefaultPlotConfiguration$new()

# Define x units
myPlotConfiguration$xUnit <- ospUnits$Time$s
# Define y units
myPlotConfiguration$yUnit <- ospUnits$`Concentration [mass]`$`µg/l`
# Change y axis scaling to logarithmic
myPlotConfiguration$yAxisScale <- tlf::Scaling$log

myPlotConfiguration$title <- "Example: Customizing a Plot"
myPlotConfiguration$subtitle <- "Using DefaultPlotConfiguration class"
myPlotConfiguration$caption <- "Source: Aciclovir data"

myPlotConfiguration$legendPosition <- tlf::LegendPositions$outsideRight

## -----------------------------------------------------------------------------
plotIndividualTimeProfile(myDataCombined, myPlotConfiguration)

## -----------------------------------------------------------------------------
indivProfile <- plotIndividualTimeProfile(myDataCombined, myPlotConfiguration)
obsVsSim <- plotObservedVsSimulated(myDataCombined, myPlotConfiguration)
resVsSim <- plotResidualsVsSimulated(myDataCombined)
resVsTime <- plotResidualsVsTime(myDataCombined)

## ----fig.width=10, fig.asp = 1------------------------------------------------
plotGridConfiguration <- PlotGridConfiguration$new()
plotGridConfiguration$tagLevels <- "a"
plotGridConfiguration$title <- "Multiple plots in one figure"

plotGridConfiguration$addPlots(plots = list(indivProfile, obsVsSim, resVsSim, resVsTime))

plotGrid(plotGridConfiguration)

## ----fig.width=10, fig.asp = 1.5----------------------------------------------
plotGridConfiguration$nColumns <- 1

plotGrid(plotGridConfiguration)

## ----save-plots, eval=FALSE---------------------------------------------------
# # Create new export configuration
# exportConfiguration <- tlf::ExportConfiguration$new()
# # Define the path to the folder where the file will be stored
# exportConfiguration$path <- "../OutputFigures"
# # Define the name of the file
# exportConfiguration$name <- "MultiPanelPlot"
# # Resolution
# exportConfiguration$dpi <- 600
# 
# # Store the plot into a variable and export it to a file
# plotObject <- plotIndividualTimeProfile(myDataCombined)
# 
# exportConfiguration$savePlot(plotObject)

