## ----setup, include = FALSE---------------------------------------------------
# Load the shared runtime gate; see vignettes/_setup.R.
source("_setup.R")
knitr::opts_chunk$set(
  eval = .ospRuntimeAvailable,
  collapse = TRUE,
  comment = "#>",
  fig.showtext = TRUE
)

## ----dimension----------------------------------------------------------------
library(ospsuite)

# Load a simulation
simFilePath <- system.file("extdata", "Aciclovir.pkml", package = "ospsuite")
sim <- loadSimulation(simFilePath)

# Get the parameter volume of the liver.
livParam <- getParameter("Organism|Liver|Volume", sim)
print(livParam)

# Dimension of the parameter
livParam$dimension

## ----allUnits-----------------------------------------------------------------
# Dimension of the parameter
livParam$dimension

# Units of the parameter
livParam$allUnits

## ----unitConversion-----------------------------------------------------------
# Get the BMI parameter
heightParam <- getParameter("Organism|Height", sim)
print(heightParam)

# Print the base and the default display units
heightParam$unit
heightParam$displayUnit

# Convert the value from the base into the default display unit
toDisplayUnit(quantity = heightParam, values = heightParam$value)

# Convert the value to the base unit, that can be used. e.g. for setting new parameter value
toBaseUnit(quantity = heightParam, values = 180, unit = "cm")

liverVolume <- getParameter("Organism|Liver|Volume", sim)
print(liverVolume)

liverVolume$allUnits

# Convert from base volume unit to µl
toUnit(quantity = liverVolume, values = c(1, 2, 3, 4), targetUnit = "ml")

