## ----include = FALSE----------------------------------------------------------
# Load the shared runtime gate; see vignettes/_setup.R.
source("_setup.R")
knitr::opts_chunk$set(
  eval = .ospRuntimeAvailable,
  collapse = TRUE,
  warning = FALSE,
  message = FALSE,
  comment = "#>",
  out.width = "100%",
  fig.height = 6,
  fig.width = 8,
  fig.showtext = TRUE
)

## -----------------------------------------------------------------------------
library(ospsuite)

# Simulation results
simFilePath <- system.file("extdata", "Aciclovir.pkml", package = "ospsuite")
sim <- loadSimulation(simFilePath)
simResults <- runSimulations(sim)[[1]]
outputPath <- "Organism|PeripheralVenousBlood|Aciclovir|Plasma (Peripheral Venous Blood)"

# observed data
obsData <- lapply(
  c("ObsDataAciclovir_1.pkml", "ObsDataAciclovir_2.pkml", "ObsDataAciclovir_3.pkml"),
  function(x) loadDataSetFromPKML(system.file("extdata", x, package = "ospsuite"))
)
# Name the elements of the list according to the names of the loaded `DataSet`.
names(obsData) <- lapply(obsData, function(x) x$name)

## -----------------------------------------------------------------------------
myDataCombined <- DataCombined$new()

## -----------------------------------------------------------------------------
myDataCombined$addSimulationResults(
  simulationResults = simResults,
  quantitiesOrPaths = outputPath,
  names = "Aciclovir Plasma",
  groups = "Aciclovir PVB"
)

## -----------------------------------------------------------------------------
myDataCombined$addDataSets(
  obsData$`Vergin 1995.Iv`,
  groups = "Aciclovir PVB"
)

## -----------------------------------------------------------------------------
dataCombinedAciclovir

## -----------------------------------------------------------------------------
myDataCombined <- DataCombined$new()

myDataCombined$addSimulationResults(
  simulationResults = simResults,
  quantitiesOrPaths = outputPath,
  names = "Aciclovir Plasma"
)

myDataCombined$addDataSets(
  obsData$`Vergin 1995.Iv`
)

plotIndividualTimeProfile(dataCombined = myDataCombined)

## -----------------------------------------------------------------------------
myDataCombined$setGroups(
  names = c("Aciclovir Plasma", obsData$`Vergin 1995.Iv`$name),
  groups = c("Aciclovir PVB", "Aciclovir PVB")
)

plotIndividualTimeProfile(dataCombined = myDataCombined)

## -----------------------------------------------------------------------------
myDataCombined$groupMap

## -----------------------------------------------------------------------------
myDataCombined$dataTransformations

## -----------------------------------------------------------------------------
myDataCombinedTranformations <- DataCombined$new()

myDataCombinedTranformations$addDataSets(
  obsData$`Vergin 1995.Iv`
)

plotIndividualTimeProfile(dataCombined = myDataCombinedTranformations)

## -----------------------------------------------------------------------------
# Check the units of the observed time values
obsData$`Vergin 1995.Iv`$xUnit

myDataCombinedTranformations$setDataTransformations(
  forNames = obsData$`Vergin 1995.Iv`$name,
  xOffsets = 24
)

plotIndividualTimeProfile(dataCombined = myDataCombinedTranformations)

## -----------------------------------------------------------------------------
myDataCombinedTranformations$setDataTransformations(
  forNames = obsData$`Vergin 1995.Iv`$name,
  yScaleFactors = 1 / 250
)

plotIndividualTimeProfile(dataCombined = myDataCombinedTranformations)

## -----------------------------------------------------------------------------
myDataCombined$toDataFrame()

## ----eval=FALSE---------------------------------------------------------------
# options(
#   pillar.width = Inf, # show all columns
#   pillar.min_chars = Inf # to turn off truncation of column titles
# )
# 
# myDataCombined$toDataFrame()

## ----echo=FALSE---------------------------------------------------------------
# change these settings only temporarily
withr::with_options(
  list(
    pillar.width = Inf, # show all columns
    pillar.min_chars = Inf # to turn off truncation of column titles
  ),
  code = {
    print(myDataCombined$toDataFrame())
  }
)

## -----------------------------------------------------------------------------
convertUnits(
  myDataCombined,
  xUnit = ospUnits$Time$s,
  yUnit = ospUnits$`Concentration [mass]`$`µg/l`
)

## -----------------------------------------------------------------------------
# Linear residuals
calculateResiduals(myDataCombined, scaling = "linear")$residualValues

# Logarithmic residuals
calculateResiduals(myDataCombined, scaling = "log")$residualValues



## -----------------------------------------------------------------------------
# Linear residuals
totalError <- sum(abs(calculateResiduals(myDataCombined, scaling = tlf::Scaling$lin)$residualValues))

print(totalError)

