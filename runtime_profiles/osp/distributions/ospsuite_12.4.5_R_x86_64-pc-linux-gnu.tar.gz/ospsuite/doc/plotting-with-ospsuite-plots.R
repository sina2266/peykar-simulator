## ----include = FALSE----------------------------------------------------------
# Load the shared runtime gate; see vignettes/_setup.R.
source("_setup.R")
knitr::opts_chunk$set(
  eval = .ospRuntimeAvailable,
  collapse = TRUE,
  warning = FALSE,
  message = FALSE,
  comment = "#>",
  out.width = "100%",
  fig.height = 6,
  fig.width = 8,
  fig.showtext = TRUE
)

## ----setup-options------------------------------------------------------------
library(ospsuite)

# Enable or disable watermark for plots
options(ospsuite.plots.watermarkEnabled = TRUE)

## ----setup--------------------------------------------------------------------
# Load simulation
simFilePath <- system.file("extdata", "Aciclovir.pkml", package = "ospsuite")
sim <- loadSimulation(simFilePath)
# simulate with two outputs
addOutputs(
  quantitiesOrPaths = "Organism|Kidney|Urine|Aciclovir|Fraction excreted to urine",
  simulation = sim
)
simResults <- runSimulations(sim)[[1]]

# Load observed data
obsData <- loadDataSetFromPKML(system.file(
  "extdata",
  "ObsDataAciclovir_1.pkml",
  package = "ospsuite"
))

# Create DataCombined object
myDataCombined <- DataCombined$new()

myDataCombined$addSimulationResults(
  simulationResults = simResults,
  quantitiesOrPaths = "Organism|PeripheralVenousBlood|Aciclovir|Plasma (Peripheral Venous Blood)",
  names = list(
    "Organism|PeripheralVenousBlood|Aciclovir|Plasma (Peripheral Venous Blood)" = "Plasma"
  ),
  groups = "Aciclovir PVB"
)

myDataCombined$addDataSets(
  obsData,
  groups = "Aciclovir PVB"
)

# Create DataCombined object with more than one simulation result and observed data set
myDataCombinedMulti <- DataCombined$new()

myDataCombinedMulti$addSimulationResults(
  simulationResults = simResults,
  quantitiesOrPaths = c(
    "Organism|PeripheralVenousBlood|Aciclovir|Plasma (Peripheral Venous Blood)",
    "Organism|Kidney|Urine|Aciclovir|Fraction excreted to urine"
  ),
  names = list(
    "Organism|PeripheralVenousBlood|Aciclovir|Plasma (Peripheral Venous Blood)" = "Plasma (Peripheral Venous Blood) ",
    "Organism|Kidney|Urine|Aciclovir|Fraction excreted to urine" = "fraction excreted"
  ),
  groups = "Aciclovir"
)

myDataCombinedMulti$addDataSets(
  obsData,
  groups = "Aciclovir"
)

obsDataUrine <- DataSet$new(name = 'urine data')
obsDataUrine$yDimension <- "Fraction"
obsDataUrine$yUnit <- ""

obsDataUrine$setValues(
  xValues = c(3, 12, 24),
  yValues = c(0.5, 0.9, 0.98),
  yErrorValues = NULL
)

myDataCombinedMulti$addDataSets(
  obsDataUrine,
  groups = "Aciclovir"
)


## ----setup-population---------------------------------------------------------
# Load population from CSV file
popFilePath <- system.file("extdata", "pop.csv", package = "ospsuite")
population <- loadPopulation(csvPopulationFile = popFilePath)

# Run population simulation
popResults <- runSimulations(simulations = sim, population = population)[[1]]

# Create DataCombined object for population
myPopDataCombined <- DataCombined$new()

myPopDataCombined$addSimulationResults(
  simulationResults = popResults,
  quantitiesOrPaths = "Organism|PeripheralVenousBlood|Aciclovir|Plasma (Peripheral Venous Blood)",
  names = list(
    "Organism|PeripheralVenousBlood|Aciclovir|Plasma (Peripheral Venous Blood)" = "Plasma"
  ),
  groups = "Aciclovir Population"
)

myPopDataCombined$addDataSets(
  obsData,
  groups = "Aciclovir Population"
)

## ----timeprofile--------------------------------------------------------------
plotTimeProfile(myDataCombined)

## ----timeprofile-population---------------------------------------------------
# Plot population data with default quantile aggregation
plotTimeProfile(myPopDataCombined, yScale = 'log')

## ----timeprofile-aggregation--------------------------------------------------
plotTimeProfile(
  myPopDataCombined,
  yScale = 'log',
  aggregation = "quantiles",
  quantiles = c(0.1, 0.5, 0.9)
)

## ----timeprofile-arithmetic---------------------------------------------------
plotTimeProfile(
  myPopDataCombined,
  yScale = 'log',
  aggregation = "arithmetic",
  nsd = 1
)

## ----timeprofile-legend-per-dataset, eval=.ospRuntimeAvailable----------------
# Show all individual dataset names (both observed and simulated) - default
plotTimeProfile(myDataCombinedMulti, showLegendPerDataset = "all")

# No per-dataset differentiation
plotTimeProfile(myDataCombinedMulti, showLegendPerDataset = "none")

# Show only observed dataset names (different shapes)
plotTimeProfile(myDataCombinedMulti, showLegendPerDataset = "observed")

# Show only simulated dataset names (different line types)
plotTimeProfile(myDataCombinedMulti, showLegendPerDataset = "simulated")


## ----timeprofile-manual-aesthetics, eval=FALSE--------------------------------
# # Show all individual dataset names (both observed and simulated)
# plotTimeProfile(
#   myDataCombinedMulti,
#   mapping = ggplot2::aes(linetype = name),
#   observedMapping = ggplot2::aes(shape = name)
# )
# 
# # Show only observed dataset names (different shapes)
# plotTimeProfile(
#   myDataCombinedMulti,
#   observedMapping = ggplot2::aes(shape = name)
# )
# 
# # Show only simulated dataset names (different line types)
# plotTimeProfile(
#   myDataCombinedMulti,
#   mapping = ggplot2::aes(linetype = name),
#   observedMapping = ggplot2::aes()
# )
# 

## ----timeprofile-mapping------------------------------------------------------
# Customize aesthetics
plotTimeProfile(
  myDataCombinedMulti,
  mapping = ggplot2::aes(color = yDimension, fill = yDimension)
)

## ----predvsobs----------------------------------------------------------------
plotPredictedVsObserved(myDataCombined)

## ----predvsobs-fold-----------------------------------------------------------
# Show 1.5-fold and 3-fold ranges
plotPredictedVsObserved(
  myDataCombined,
  comparisonLineVector = ospsuite.plots::getFoldDistanceList(folds = c(1.5, 3))
)

## ----predvsobs-swap-----------------------------------------------------------
# Put predicted on x-axis, observed on y-axis
plotPredictedVsObserved(myDataCombined, predictedAxis = "x")

## ----predvsobs-scale----------------------------------------------------------
# Use linear scale instead of log
plotPredictedVsObserved(myDataCombined, xyScale = "linear")

## ----predvsobs-legend-per-dataset, eval=FALSE---------------------------------
# # Show individual observed dataset names (different shapes) (default)
# plotPredictedVsObserved(myDataCombined, showLegendPerDataset = "all")
# 
# # No per-dataset differentiation
# plotPredictedVsObserved(myDataCombined, showLegendPerDataset = "none")

## ----resvsobs-----------------------------------------------------------------
plotResidualsVsCovariate(myDataCombined, xAxis = "observed")

## ----resvstime----------------------------------------------------------------
plotResidualsVsCovariate(myDataCombined, xAxis = "time")

## ----resvspred----------------------------------------------------------------
plotResidualsVsCovariate(myDataCombined, xAxis = "predicted")

## ----resvsobs-scale-----------------------------------------------------------
# Use linear residuals
plotResidualsVsCovariate(
  myDataCombined,
  xAxis = "observed",
  residualScale = "linear"
)

## ----resvscovariate-legend-per-dataset, eval=FALSE----------------------------
# # Show individual observed dataset names (different shapes) (default)
# plotResidualsVsCovariate(myDataCombined, showLegendPerDataset = "all")
# 
# # No per-dataset differentiation
# plotResidualsVsCovariate(myDataCombined, showLegendPerDataset = "none")

## ----reshist------------------------------------------------------------------
plotResidualsAsHistogram(myDataCombined)

## ----reshist-dist, eval=FALSE-------------------------------------------------
# # Without distribution overlay
# plotResidualsAsHistogram(myDataCombined, distribution = 'none')

## ----reshist-scale, eval=FALSE------------------------------------------------
# # Linear residuals histogram
# plotResidualsAsHistogram(myDataCombined, residualScale = "linear")

## ----qqplot-------------------------------------------------------------------
plotQuantileQuantilePlot(myDataCombined)

## ----qqplot-scale, eval=FALSE-------------------------------------------------
# # Use linear residuals
# plotQuantileQuantilePlot(myDataCombined, residualScale = "linear")

## ----units-direct-------------------------------------------------------------
# Default: auto-detected units (e.g. µmol/l and h from the data)
plotTimeProfile(myDataCombined)

## ----units-set----------------------------------------------------------------
# Override x-axis unit: display time in minutes instead of hours
plotTimeProfile(myDataCombined, xUnit = "min", yUnit = "mg/l")

## ----units-equivalent, eval=FALSE---------------------------------------------
# plotTimeProfile(convertUnits(myDataCombined, xUnit = "min", yUnit = "mg/l"))

## ----custom, eval=FALSE-------------------------------------------------------
# library(ggplot2)
# 
# # Create a plot and customize it
# p <- plotTimeProfile(myDataCombined)
# 
# # Add customizations
# p <- p +
#   theme_minimal() +
#   labs(title = "My Custom Title") +
#   theme(legend.position = "bottom")
# 
# print(p)

## ----legend-title, eval=FALSE-------------------------------------------------
# # Re-enable the (default ggplot2) legend title
# p <- plotTimeProfile(myDataCombined) +
#   ggplot2::theme(legend.title = ggplot2::element_text())
# 
# print(p)

## ----legend-position, eval=FALSE----------------------------------------------
# library(ggplot2)
# 
# p <- plotTimeProfile(myDataCombined)
# 
# # Move the legend below the plot
# p + theme(legend.position = "bottom")
# 
# # Remove the legend entirely
# p + theme(legend.position = "none")
# 
# # Place the legend inside the panel, anchored to its top-right corner
# p + theme(
#   legend.position = "inside",
#   legend.position.inside = c(0.95, 0.95),
#   legend.justification.inside = c("right", "top")
# )

## ----save, eval=FALSE---------------------------------------------------------
# # Create a plot
# myPlot <- plotTimeProfile(myDataCombined)
# 
# # Save to file using ospsuite.plots::exportPlot
# ospsuite.plots::exportPlot(
#   plotObject = myPlot,
#   filePath = "timeprofile.png",
#   width = 8,
#   height = NULL,
#   dpi = 300
# )

## ----save-ggsave, eval=FALSE--------------------------------------------------
# # Save using ggsave
# ggsave("timeprofile.png", myPlot, width = 8, height = 6, dpi = 300)

