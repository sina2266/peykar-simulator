## ----include = FALSE----------------------------------------------------------
# Load the shared runtime gate; see vignettes/_setup.R.
source("_setup.R")
knitr::opts_chunk$set(
  eval = .ospRuntimeAvailable,
  collapse = TRUE,
  comment = "#>"
)

