## ----include = FALSE----------------------------------------------------------
# Load the shared runtime gate; see vignettes/_setup.R.
source("_setup.R")
knitr::opts_chunk$set(
  eval = .ospRuntimeAvailable,
  collapse = TRUE,
  comment = "#>",
  fig.showtext = TRUE,
  message = FALSE,
  warning = FALSE
)

## ----echo=TRUE, results='hide'------------------------------------------------
# Load the ospsuite package
library(ospsuite)
options(ospsuite.plots.watermarkEnabled = FALSE)

# Load the built-in example simulation
simFilePath <- system.file("extdata", "Aciclovir.pkml", package = "ospsuite")
sim <- loadSimulation(simFilePath)

# Run the simulation
results <- runSimulations(sim)

# Create a quick visualization
myDataCombined <- DataCombined$new()
myDataCombined$addSimulationResults(results[[1]])
plotTimeProfile(myDataCombined)

## ----echo=TRUE, message=TRUE--------------------------------------------------
# Using the included example
simFilePath <- system.file("extdata", "Aciclovir.pkml", package = "ospsuite")
sim <- loadSimulation(simFilePath)

# For custom files, use:
# sim <- loadSimulation("path/to/simulation.pkml")

# Explore the simulation
print(sim)

## ----echo=TRUE----------------------------------------------------------------
# Get the simulation tree structure
simTree <- getSimulationTree(sim)

# Explore parameter paths
simTree$Organism$Weight$path

# Find parameters using wildcards
getAllParametersMatching("**|Dose*", sim)

# Or search for specific terms
grep("Dose", getAllParameterPathsIn(container = sim), value = TRUE)

## ----echo=TRUE, message=TRUE--------------------------------------------------
# Get a specific parameter
dose <- getParameter(
  path = "Events|IV 250mg 10min|Application_1|ProtocolSchemaItem|Dose",
  sim
)
print(dose)

# Change the dose value
setParameterValues(dose, 0.004) # New dose: 4 mg/kg
print(dose)

# Scale a parameter by a factor
scaleParameterValues(dose, factor = 2) # Double the dose
print(dose)

# Reset to original value
dose$reset()
print(dose)

## ----echo=TRUE, message=TRUE--------------------------------------------------

# Originally, the simulation outputs plasma concentrations
sim$outputSelections

# Add new outputs to track
addOutputs(c("Organism|Lumen|Stomach|Aciclovir"), simulation = sim)

# Now, the simulation will compute two outputs
sim$outputSelections

# Adjust solver precision if needed
sim$solver$absTol <- 1e-12
sim$solver$relTol <- 1e-8

# Add custom output intervals for higher resolution
addOutputInterval(
  simulation = sim,
  startTime = 1440, # 1 day
  endTime = 3000, # ~2 days
  resolution = 10, # Every 10 minutes
  intervalName = "highRes"
)

# Check current output schema
print(sim$outputSchema)

## ----echo=TRUE, warning=FALSE-------------------------------------------------
# Run the simulation
results <- runSimulations(sim)

# Examine the results structure
print(results[[1]])

# Extract specific concentration-time data
plasmaConc <- results[[1]]$getValuesByPath(
  "Organism|PeripheralVenousBlood|Aciclovir|Plasma (Peripheral Venous Blood)",
  individualIds = 0
)
head(plasmaConc)

## ----echo=TRUE----------------------------------------------------------------
# Create a DataCombined object for plotting
myDataCombined <- DataCombined$new()
myDataCombined$addSimulationResults(
  results[[1]],
  quantitiesOrPaths = "Organism|PeripheralVenousBlood|Aciclovir|Plasma (Peripheral Venous Blood)"
)

# Convert to data frame if needed
df_results <- myDataCombined$toDataFrame()
head(df_results)

# Create publication-ready plots
plotTimeProfile(myDataCombined)

## ----echo=TRUE----------------------------------------------------------------
library(ggplot2)

# Transform simulation results to a dataframe
results_df <- simulationResultsToDataFrame(
  results[[1]],
  quantitiesOrPaths = "Organism|PeripheralVenousBlood|Aciclovir|Plasma (Peripheral Venous Blood)"
)

results_df$Time <- results_df$Time / (60 * 24) # Convert to days

ggplot(results_df, aes(x = Time, y = simulationValues)) +
  geom_line(color = "blue", size = 1) +
  labs(
    title = "Aciclovir Plasma Concentration over Time",
    x = "Time (days)",
    y = "Plasma Concentration (µmol/L)"
  ) +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5))

## ----echo=TRUE, message=TRUE--------------------------------------------------
# 1. Load simulation
simFilePath <- system.file("extdata", "Aciclovir.pkml", package = "ospsuite")
sim <- loadSimulation(simFilePath)

# 2. Modify parameters (e.g., change dose)
dose <- getParameter(
  path = "Events|IV 250mg 10min|Application_1|ProtocolSchemaItem|Dose",
  sim
)
setParameterValues(dose, 0.006) # 6 mg/kg dose

# 3. Run simulation
results <- runSimulations(sim)

# 4. Visualize results
myDataCombined <- DataCombined$new()
myDataCombined$addSimulationResults(results[[1]])
plotTimeProfile(myDataCombined)

# 5. Extract data for further analysis
df_results <- myDataCombined$toDataFrame()
print(paste("Peak concentration:", round(max(df_results$yValues), 2), "µmol/L"))

