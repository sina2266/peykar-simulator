### only observed ------------------------
test_that("It creates default plots as expected for single observed dataset", {
  set.seed(123)

  vdiffr::expect_doppelganger(
    title = "single obs",
    fig = plotTimeProfile(oneObsDC())
  )
})

test_that("It creates default plots as expected for multiple observed datasets", {
  set.seed(123)

  vdiffr::expect_doppelganger(
    title = "multiple obs",
    fig = plotTimeProfile(manyObsDC())
  )

  vdiffr::expect_doppelganger(
    title = "multiple obs - separate legend",
    fig = plotTimeProfile(
      manyObsDC(),
      mapping = ggplot2::aes(groupby = name)
    )
  )

  vdiffr::expect_doppelganger(
    title = "multiple obs - showLegendPerDataset none",
    fig = plotTimeProfile(manyObsDC(), showLegendPerDataset = "none")
  )

  vdiffr::expect_doppelganger(
    title = "multiple obs - showLegendPerDataset observed",
    fig = plotTimeProfile(manyObsDC(), showLegendPerDataset = "observed")
  )
})

# only simulated ------------------------

test_that("It creates default plots as expected for single simulated dataset", {
  set.seed(123)
  vdiffr::expect_doppelganger(
    title = "single sim",
    fig = plotTimeProfile(oneSimDC())
  )
})

test_that("It plots multiple simulated datasets with dataset name legend entries", {
  set.seed(123)
  vdiffr::expect_doppelganger(
    title = "multiple sim - separate legend",
    fig = plotTimeProfile(manySimDC())
  )

  vdiffr::expect_doppelganger(
    title = "multiple sim - showLegendPerDataset none",
    fig = plotTimeProfile(manySimDC(), showLegendPerDataset = "none")
  )

  vdiffr::expect_doppelganger(
    title = "multiple sim - showLegendPerDataset simulated",
    fig = plotTimeProfile(manySimDC(), showLegendPerDataset = "simulated")
  )
})

# single observed and simulated datasets ------------------------

test_that("It creates default plots as expected for both observed and simulated", {
  set.seed(123)
  vdiffr::expect_doppelganger(
    title = "both - default",
    fig = plotTimeProfile(oneObsSimDC())
  )
})

# multiple observed and simulated datasets ------------------------

test_that("It creates default plot with group legend for multiple obs and sim", {
  set.seed(123)
  vdiffr::expect_doppelganger(
    title = "many obs sim - default",
    fig = plotTimeProfile(manyObsSimDC())
  )
})

test_that("It maps multiple observed and simulated datasets to different visual properties", {
  set.seed(123)

  vdiffr::expect_doppelganger(
    title = "many obs sim - showLegendPerDataset none",
    fig = plotTimeProfile(manyObsSimDC(), showLegendPerDataset = "none")
  )

  vdiffr::expect_doppelganger(
    title = "many obs sim - showLegendPerDataset observed",
    fig = plotTimeProfile(
      manyObsSimDC(),
      showLegendPerDataset = "observed"
    )
  )

  vdiffr::expect_doppelganger(
    title = "many obs sim - showLegendPerDataset simulated",
    fig = plotTimeProfile(
      manyObsSimDC(),
      showLegendPerDataset = "simulated"
    )
  )
})

test_that("It applies yScale and yScaleArgs to multiple obs and sim datasets", {
  set.seed(123)
  vdiffr::expect_doppelganger(
    title = "many obs sim - log scale",
    fig = plotTimeProfile(
      manyObsSimDC(),
      yScale = "log",
      yScaleArgs = list(limits = c(0.001, NA))
    )
  )
})

test_that("User-provided mappings override showLegendPerDataset", {
  set.seed(123)
  # User mapping should override internal showLegendPerDataset mapping
  vdiffr::expect_doppelganger(
    title = "user mapping overrides showLegendPerDataset",
    fig = plotTimeProfile(
      manyObsSimDC(),
      showLegendPerDataset = "all",
      mapping = ggplot2::aes(color = name, linetype = NULL),
      observedMapping = ggplot2::aes(
        color = name,
        fill = name,
        shape = dataType
      ),
    )
  )
})

# showLegendPerDataset parameter validation and warnings ------------------------

test_that("It warns when showLegendPerDataset setting doesn't match data", {
  # Only observed data, but asking for simulated differentiation
  expect_warning(
    plotTimeProfile(manyObsDC(), showLegendPerDataset = "simulated"),
    regexp = "showLegendPerDataset = \"simulated\".*but no.*simulated.*data present"
  )

  # Only simulated data, but asking for observed differentiation
  expect_warning(
    plotTimeProfile(manySimDC(), showLegendPerDataset = "observed"),
    regexp = "showLegendPerDataset = \"observed\".*but no.*observed.*data present"
  )
})

test_that("It warns when user mapping contains untypical aesthetics", {
  # User shape is unusual for simulated
  expect_warning(
    plotTimeProfile(
      manySimDC(),
      mapping = ggplot2::aes(shape = dataType)
    ),
    messages$plotUntypicalAesthetic(
      aesthetic = 'shape',
      dataType = "simulated"
    )
  )

  # User shape is unusual for simulated
  expect_warning(
    plotTimeProfile(
      manyObsDC(),
      observedMapping = ggplot2::aes(linetype = dataType)
    ),
    messages$plotUntypicalAesthetic(
      aesthetic = 'linetype',
      dataType = "observed"
    )
  )
})

test_that("line width does not leak into observedMapping", {
  expect_no_warning(
    plotTimeProfile(
      manyObsSimDC(),
      mapping = ggplot2::aes(linetype = name)
    )
  )
})

# edge cases ------------------------

test_that("It works when geometric error is present", {
  set.seed(123)
  vdiffr::expect_doppelganger(
    title = "geometric error",
    fig = plotTimeProfile(oneObsGeometricDC())
  )
})

test_that("It returns `NULL` with warning when `DataCombined` is empty", {
  myCombDat <- DataCombined$new()

  expect_warning(
    result <- plotTimeProfile(myCombDat),
    regexp = messages$plotNoDataAvailable()
  )
  expect_null(result)
})

# LLOQ ----

test_that("It plots LLOQ correctly on log scale", {
  set.seed(42)
  dataSet <- DataSet$new("ds with lloq")
  dataSet$setValues(
    1:9,
    c(10 * exp(1:-5) + rnorm(7, 0, .25), rep(0.075, 2)),
    c(abs(rnorm(7, 0, 0.2)), rep(NA, 2))
  )
  dataSet$LLOQ <- 0.15

  dc <- DataCombined$new()
  dc$addDataSets(dataSet)

  vdiffr::expect_doppelganger(
    title = "lloq",
    fig = plotTimeProfile(dc, yScale = "log")
  )
})

# 2 y-axis dimensions ----
test_that("It plots data with two y-axis dimensions (fraction and concentration)", {
  vdiffr::expect_doppelganger(
    title = "with_secAxis",
    fig = plotTimeProfile(manyObsSimDCWithFraction(), yScale = "log") +
      ggplot2::theme(
        legend.position = "inside",
        legend.position.inside = c(0.95, 0.05),
        legend.justification.inside = c("right", "bottom")
      )
  )
})

# xUnit / yUnit direct parameters ----

test_that("It converts x-axis units when xUnit is provided", {
  # Default: x in h; override to "min"
  plotDefault <- plotTimeProfile(oneObsDC())

  plotMinutes <-
    plotTimeProfile(oneObsDC(), xUnit = "min")

  # The x-axis label should contain "min" when xUnit = "min"
  expect_true(
    grepl("min", plotMinutes$labels$x, fixed = TRUE),
    info = "x-axis label should contain 'min' when xUnit = 'min'"
  )
  # The default plot's x-axis label should not contain "min"
  expect_false(
    grepl("min", plotDefault$labels$x, fixed = TRUE),
    info = "default x-axis label should not contain 'min'"
  )
})

test_that("It converts y-axis units when yUnit is provided", {
  # most frequent units would be xUnit 'h',yUnit 'mg/l', y2Unit = ''
  # overwrite this with userdefined units
  plotNonDefaultUnits <- plotTimeProfile(
    manyObsSimDCWithFraction(),
    xUnit = 'day(s)',
    yUnit = 'ng/l',
    y2Unit = '%'
  )

  vdiffr::expect_doppelganger(
    title = "userSet units",
    fig = plotNonDefaultUnits
  )
})


test_that("It produces the same result as pre-converting with convertUnits", {
  # Passing units directly should be equivalent to calling convertUnits first
  plotDirect <- plotTimeProfile(
    oneObsSimDC(),
    xUnit = "day(s)",
    yUnit = 'mg/l'
  )
  plotPreConverted <- plotTimeProfile(convertUnits(
    oneObsSimDC(),
    yUnit = 'mg/l',
    xUnit = "day(s)"
  ))

  expect_equal(plotDirect$data, plotPreConverted$data)

  plotDataFrame <- plotTimeProfile(
    oneObsSimDC()$toDataFrame(),
    xUnit = "day(s)",
    yUnit = 'mg/l'
  )

  expect_equal(plotDirect$data, plotDataFrame$data)
})
