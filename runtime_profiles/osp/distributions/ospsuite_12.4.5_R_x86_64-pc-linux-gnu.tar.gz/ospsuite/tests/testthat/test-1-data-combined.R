# data to be used ---------------------------------------

# `loadDataSetsFromExcel()` does not work for non-Windows platforms

# load the simulation
sim_immutable <- loadTestSimulation(
  "simple",
  loadFromCache = TRUE,
  addToCache = TRUE
)
simResults <- importResultsFromCSV(
  simulation = sim_immutable,
  filePaths = getTestDataFilePath("Stevens_2012_placebo_indiv_results.csv")
)

# import observed data (will return a list of DataSet objects)
dataSet <- loadDataSetsFromExcel(
  xlsFilePath = getTestDataFilePath("CompiledDataSetStevens2012.xlsx"),
  importerConfiguration = loadDataImporterConfiguration(getTestDataFilePath(
    "ImporterConfiguration.xml"
  ))
)

# same as `dataSet`, but with deliberately changed entries for testing
dataSet2 <- loadDataSetsFromExcel(
  xlsFilePath = getTestDataFilePath("CompiledDataSetStevens2012v2.xlsx"),
  importerConfiguration = loadDataImporterConfiguration(getTestDataFilePath(
    "ImporterConfiguration.xml"
  ))
)

# active bindings ---------------------------------------

test_that("active bindings should all be NULL for empty initialization", {
  myCombDat <- DataCombined$new()

  expect_null(myCombDat$groupMap)
  expect_null(myCombDat$names)
  expect_null(myCombDat$toDataFrame())
  expect_equal(
    myCombDat$dataTransformations,
    dplyr::tibble(
      name = character(),
      xOffsets = numeric(),
      yOffsets = numeric(),
      xScaleFactors = numeric(),
      yScaleFactors = numeric()
    )
  )
})

test_that("active bindings are read-only", {
  myCombDat <- DataCombined$new()

  expect_error(
    myCombDat$groupMap <- "x",
    messages$errorPropertyReadOnly("groupMap"),
    fixed = TRUE
  )

  expect_error(
    myCombDat$names <- "x",
    messages$errorPropertyReadOnly("names"),
    fixed = TRUE
  )

  expect_error(
    myCombDat$dataTransformations <- "x",
    messages$errorPropertyReadOnly("dataTransformations"),
    fixed = TRUE
  )
})

test_that("add* methods error if anything but expected data types are entered", {
  myCombDat <- DataCombined$new()

  expect_error(
    myCombDat$addSimulationResults(list("x", "y")),
    messages$errorWrongType(
      "simulationResults",
      type = "list",
      "SimulationResults"
    ),
    fixed = TRUE
  )

  expect_error(
    myCombDat$addDataSets(list(1, 2)),
    messages$errorWrongType("dataSets", type = "list", "DataSet"),
    fixed = TRUE
  )
})

# only `DataSet` ---------------------------------------

test_that("data transformations work as expected when only `DataSet` is provided", {
  myCombDat <- DataCombined$new()
  myCombDat$addDataSets(dataSet[[1]])

  # data transformations should already be setup with the defaults
  expect_equal(
    myCombDat$dataTransformations,
    structure(
      list(
        name = "Stevens_2012_placebo.Placebo_total",
        xOffsets = 0,
        yOffsets = 0,
        xScaleFactors = 1,
        yScaleFactors = 1
      ),
      class = c("tbl_df", "tbl", "data.frame"),
      row.names = c(NA, -1L)
    )
  )
})

test_that("data frame dimensions are as expected when only `DataSet` is provided", {
  myCombDat <- DataCombined$new()
  myCombDat$addDataSets(dataSet[[1]])
  df <- myCombDat$toDataFrame()

  expect_equal(nrow(df), 12L)
})

test_that("data frame column and dataset names are as expected when only `DataSet` is provided", {
  myCombDat <- DataCombined$new()
  myCombDat$addDataSets(dataSet[[1]])
  df <- myCombDat$toDataFrame()

  expect_equal(
    sort(names(df)),
    sort(c(
      "name",
      "group",
      "dataType",
      "xValues",
      "xUnit",
      "xDimension",
      "yValues",
      "yUnit",
      "yDimension",
      "yErrorValues",
      "yErrorType",
      "yErrorUnit",
      "molWeight",
      "lloq",
      "Sheet",
      "Group Id"
    ))
  )

  expect_equal(as.character(unique(df$name)), names(dataSet)[[1]])
})


test_that("dataType can be changed after dataset is added", {
  myDC <- DataCombined$new()

  simData <- DataSet$new(name = "Simulated")
  simData$setValues(xValues = c(0, 2, 4), yValues = c(0, 4, 8))

  obsData <- DataSet$new(name = "Observed")
  obsData$setValues(
    xValues = c(1, 3, 3.5, 4, 5),
    yValues = c(1.9, 6.1, 7, 8.2, 1)
  )

  myDC$addDataSets(c(obsData, simData), groups = "myGroup")

  expect_snapshot({
    myDC$setDataTypes(
      names = c("Observed", "Simulated"),
      dataTypes = c("observed", "simulated")
    )
  })
})

# only `SimulationResults` ---------------------------------------

test_that("data transformations work as expected when only `SimulationResults` is provided", {
  myCombDat <- DataCombined$new()
  myCombDat$addSimulationResults(simResults)

  # data transformations should already be setup with the defaults
  expect_equal(
    myCombDat$dataTransformations,
    structure(
      list(
        name = c(
          "Organism|Lumen|Stomach|Dapagliflozin|Gastric emptying",
          "Organism|Lumen|Stomach|Dapagliflozin|Gastric retention",
          "Organism|Lumen|Stomach|Metformin|Gastric retention distal",
          "Organism|Lumen|Stomach|Metformin|Gastric retention proximal",
          "Organism|Lumen|Stomach|Metformin|Gastric retention"
        ),
        xOffsets = c(0, 0, 0, 0, 0),
        yOffsets = c(0, 0, 0, 0, 0),
        xScaleFactors = c(1, 1, 1, 1, 1),
        yScaleFactors = c(1, 1, 1, 1, 1)
      ),
      class = c("tbl_df", "tbl", "data.frame"),
      row.names = c(NA, -5L)
    )
  )
})

test_that("data frame dimensions are as expected when only `SimulationResults` is provided", {
  myCombDat <- DataCombined$new()
  myCombDat$addSimulationResults(simResults)
  df <- myCombDat$toDataFrame()

  expect_equal(nrow(df), 1255L)
})

test_that("data frame column names and datset names are as expected when only `SimulationResults` is provided", {
  myCombDat <- DataCombined$new()
  myCombDat$addSimulationResults(simResults)
  df <- myCombDat$toDataFrame()

  expect_equal(
    sort(names(df)),
    sort(c(
      "name",
      "group",
      "dataType",
      "xValues",
      "xUnit",
      "xDimension",
      "yValues",
      "yUnit",
      "yDimension",
      "yErrorValues",
      "IndividualId",
      "molWeight"
    ))
  )
  expect_equal(
    sort(as.character(unique(df$name))),
    sort(simResults$allQuantityPaths)
  )
  expect_equal(
    sort(as.character(na.omit(unique(df$name)))),
    sort(c(
      "Organism|Lumen|Stomach|Dapagliflozin|Gastric emptying",
      "Organism|Lumen|Stomach|Dapagliflozin|Gastric retention",
      "Organism|Lumen|Stomach|Metformin|Gastric retention",
      "Organism|Lumen|Stomach|Metformin|Gastric retention distal",
      "Organism|Lumen|Stomach|Metformin|Gastric retention proximal"
    ))
  )
})

test_that("data frame molecular weight column values are as expected", {
  myCombDat <- DataCombined$new()
  myCombDat$addSimulationResults(simResults)
  df <- myCombDat$toDataFrame()

  expect_equal(unique(df$molWeight), c(408.8730, 129.1636))
})

test_that("`name` is a factor preserving dataset insertion order", {
  # `name` must be a factor so that downstream ggplot2 legends follow the
  # order in which datasets were added, rather than alphabetical order.
  myCombDat <- DataCombined$new()
  myCombDat$addDataSets(dataSet[[3]])
  myCombDat$addDataSets(dataSet[[1]])
  myCombDat$addDataSets(dataSet[[2]])

  df <- myCombDat$toDataFrame()

  expect_s3_class(df$name, "factor")
  # Levels must follow insertion order, which differs from alphabetical order.
  expect_equal(
    levels(df$name),
    names(dataSet)[c(3, 1, 2)]
  )
  # `self$names` (insertion order) and the factor levels must coincide.
  expect_equal(levels(df$name), myCombDat$names)
})

test_that("`group` is a factor preserving group introduction order", {
  # `group` must be a factor whose levels follow the order in which each group
  # is first introduced, so `group` and `name` legends stay consistent in plots
  # (notably in observed-vs-predicted plots where the two variables may differ).
  myCombDat <- DataCombined$new()
  myCombDat$addDataSets(dataSet[[1]], groups = "second")
  myCombDat$addDataSets(dataSet[[2]], groups = "first")
  myCombDat$addDataSets(dataSet[[3]], groups = "second")

  df <- myCombDat$toDataFrame()

  expect_s3_class(df$group, "factor")
  # Levels follow first-appearance order among the added datasets, which here
  # differs from alphabetical order ("first" < "second").
  expect_equal(levels(df$group), c("second", "first"))
})

# Performance tests are only run on machines
# with the OSPSUITE-BENCHMARK-TESTS environment variable set to TRUE
if (Sys.getenv("OSPSUITE-BENCHMARK-TESTS") == "TRUE") {
  # This is an example benchmark that takes around 4 seconds
  benchmark_1e8 <- system.time({
    for (i in 1:1e8) {
      res <- 2**0.5
    }
  })
  # In the current implementation, 100 runs of simulationResultsToDataFrame() work
  # approximately twice faster than the benchmark above
  test_that("The simulationResultsToDataFrame() performance is not degraded, compared to a reference performance", {
    benchmark <- system.time({
      for (i in 1:100) {
        simulationResultsToDataFrame(simResults)
      }
    })
    expect_lt(benchmark[["elapsed"]], benchmark_1e8[["elapsed"]])
  })
}

# grouping validation ---------------------------------------

test_that("with no grouping specified, group column in data frame is `NA`", {
  myCombDat <- DataCombined$new()
  myCombDat$addDataSets(dataSet[[1]])
  df <- myCombDat$toDataFrame()

  expect_equal(as.factor(rep(NA_character_, length(df$group))), df$group)
})


test_that("grouping specification fails when there are no datasets present", {
  myCombDat <- DataCombined$new()

  expect_error(
    myCombDat$setGroups(names = c("x", "y"), groups = c("a", "b")),
    "There are currently no datasets to be grouped."
  )
})

test_that("grouping specification fails when arguments are empty", {
  myCombDat <- DataCombined$new()
  myCombDat$addSimulationResults(simResults)

  expect_error(
    myCombDat$setGroups(names = character(), groups = c("a", "b")),
    messages$errorEmpty("arg"),
    fixed = TRUE
  )

  expect_error(
    myCombDat$setGroups(names = c("a", "b"), groups = character()),
    messages$errorEmpty("arg"),
    fixed = TRUE
  )
})

test_that("setting groups fails when arguments are not of `character` type", {
  myCombDat <- DataCombined$new()
  myCombDat$addDataSets(dataSet)

  x <- list(2, 4)

  expect_error(
    myCombDat$setGroups(x, list("a", "b")),
    messages$errorWrongType("arg", "list", "character"),
    fixed = TRUE
  )

  expect_error(
    myCombDat$setGroups(list(names = "a", "b"), x),
    messages$errorWrongType("arg", "list", "character"),
    fixed = TRUE
  )
})

test_that("setting groups fails when group specification is same for multiple datsets", {
  myCombDat <- DataCombined$new()
  myCombDat$addDataSets(dataSet)

  expect_error(
    myCombDat$setGroups(
      names = c(
        "Stevens_2012_placebo.Placebo_distal",
        "Stevens_2012_placebo.Placebo_distal"
      ),
      groups = c("a", "b")
    ),
    "Object has duplicated values; only unique values are allowed."
  )
})

test_that("assigning groups produces a message if dataset name is not found", {
  myCombDat <- DataCombined$new()
  myCombDat$addDataSets(dataSet[[1]])

  expect_message(
    myCombDat$setGroups(
      names = list("Stevens_2012_placebo.Placebo_total", "x", "y"),
      groups = list("m", "a", "b")
    ),
    "Following datasets were specified to be grouped but not found:
- x
- y
",
    fixed = TRUE
  )
})

# grouping with add --------------------------

test_that("group assignment with `$addDatasets()` works even if names are not provided", {
  myCombDat <- DataCombined$new()
  myCombDat$addDataSets(dataSet[[1]], groups = "m")
  expect_equal(myCombDat$groupMap$name, dataSet[[1]]$name)
  expect_equal(myCombDat$groupMap$group, "m")
})

test_that("group assignment with `$addDatasets()` works if names are provided", {
  myCombDat <- DataCombined$new()
  myCombDat$addDataSets(dataSet[[1]], names = "Placebo_total", groups = "m")
  expect_equal(myCombDat$groupMap$name, "Placebo_total")
  expect_equal(myCombDat$groupMap$group, "m")
})

test_that("group assignment with `$addSimulationResults()` works even if names are not provided", {
  myCombDat <- DataCombined$new()
  myCombDat$addSimulationResults(
    simResults,
    groups = list("a", "b", "c", "d", "e")
  )
  expect_equal(myCombDat$groupMap$name, simResults$allQuantityPaths)
  expect_equal(myCombDat$groupMap$group, c("a", "b", "c", "d", "e"))
})

test_that("group assignment with `$addSimulationResults()` works if names are provided", {
  myCombDat <- DataCombined$new()
  myCombDat$addSimulationResults(
    simResults,
    names = list("l", "m", "n", "o", "p"),
    groups = list("a", NULL, "b", "c", "d")
  )

  expect_equal(sort(myCombDat$groupMap$name), sort(c("l", "n", "o", "p", "m")))
  expect_equal(sort(myCombDat$groupMap$group), sort(c("a", "b", "c", "d", NA)))
})


# grouping with set --------------------------

test_that("assigned group can be removed using `NA` or `NULL`", {
  myCombDat <- DataCombined$new()
  myCombDat$addDataSets(dataSet[[1]])

  myCombDat$setGroups(
    names = "Stevens_2012_placebo.Placebo_total",
    groups = "m"
  )
  myCombDat$setGroups(
    names = "Stevens_2012_placebo.Placebo_total",
    groups = NA_real_
  )
  expect_equal(myCombDat$groupMap$group, NA_character_)

  myCombDat$setGroups(
    names = "Stevens_2012_placebo.Placebo_total",
    groups = "m"
  )
  myCombDat$setGroups(
    names = "Stevens_2012_placebo.Placebo_total",
    groups = list(NULL)
  )
  expect_equal(myCombDat$groupMap$group, NA_character_)
})

test_that("existing grouping can be removed using `$removeGroupAssignment()` method", {
  myCombDat <- DataCombined$new()
  myCombDat$addDataSets(dataSet[[1]])

  myCombDat$setGroups(
    names = "Stevens_2012_placebo.Placebo_total",
    groups = "m"
  )
  myCombDat$removeGroupAssignment(names = "Stevens_2012_placebo.Placebo_total")
  expect_equal(myCombDat$groupMap$group, NA_character_)

  myCombDat$setGroups(
    names = "Stevens_2012_placebo.Placebo_total",
    groups = "m"
  )
  myCombDat$removeGroupAssignment(
    names = list("Stevens_2012_placebo.Placebo_total")
  )
  expect_equal(myCombDat$groupMap$group, NA_character_)
})

test_that("setting groups with atomic vector or list shouldn't make a difference", {
  myCombDat <- DataCombined$new()
  myCombDat$addSimulationResults(simResults)
  myCombDat$setGroups(
    names = c(
      "Organism|Lumen|Stomach|Dapagliflozin|Gastric emptying",
      "Organism|Lumen|Stomach|Dapagliflozin|Gastric retention"
    ),
    groups = c("x", "y")
  )

  myCombDat2 <- DataCombined$new()
  myCombDat2$addSimulationResults(simResults)
  myCombDat2$setGroups(
    names = list(
      "Organism|Lumen|Stomach|Dapagliflozin|Gastric emptying",
      "Organism|Lumen|Stomach|Dapagliflozin|Gastric retention"
    ),
    groups = list("x", "y")
  )

  expect_equal(myCombDat$groupMap, myCombDat2$groupMap)
  expect_equal(myCombDat$toDataFrame(), myCombDat2$toDataFrame())
})


test_that("specifying groupings and new names for only few paths in `SimulationResults` works as expected", {
  myCombDat <- DataCombined$new()
  myCombDat$addSimulationResults(
    simResults,
    quantitiesOrPaths = c(
      "Organism|Lumen|Stomach|Dapagliflozin|Gastric emptying",
      "Organism|Lumen|Stomach|Metformin|Gastric retention distal",
      "Organism|Lumen|Stomach|Metformin|Gastric retention"
    ),
    names = c("x", NA_character_, "y")
  )
  myCombDat$setGroups(names = list("x", "y"), groups = list("a", "b"))

  expect_equal(dplyr::filter(myCombDat$groupMap, group == "a")$name[[1]], "x")
  expect_equal(dplyr::filter(myCombDat$groupMap, group == "b")$name[[1]], "y")
  expect_equal(
    dplyr::filter(myCombDat$groupMap, !group %in% c("a", "b"))$name[[1]],
    "Organism|Lumen|Stomach|Metformin|Gastric retention distal"
  )
})

# both `DataSet` and `SimulationResults` ---------------------------------------

test_that("data transformations as expected when both `DataSet` and `SimulationResults` provided", {
  myCombDat <- DataCombined$new()
  myCombDat$addSimulationResults(
    simResults,
    quantitiesOrPaths = c(
      "Organism|Lumen|Stomach|Dapagliflozin|Gastric retention",
      "Organism|Lumen|Stomach|Dapagliflozin|Gastric emptying",
      "Organism|Lumen|Stomach|Metformin|Gastric retention"
    ),
    names = list("x", "y", "z")
  )
  myCombDat$addDataSets(dataSet, names = list("a", NULL, "b", NULL, "c", NULL))

  expect_equal(
    myCombDat$dataTransformations,
    structure(
      list(
        name = c(
          "x",
          "y",
          "z",
          "a",
          "Stevens_2012_placebo.Sita_total",
          "b",
          "Stevens_2012_placebo.Sita_proximal",
          "c",
          "Stevens_2012_placebo.Sita_dist"
        ),
        xOffsets = c(0, 0, 0, 0, 0, 0, 0, 0, 0),
        yOffsets = c(0, 0, 0, 0, 0, 0, 0, 0, 0),
        xScaleFactors = c(1, 1, 1, 1, 1, 1, 1, 1, 1),
        yScaleFactors = c(1, 1, 1, 1, 1, 1, 1, 1, 1)
      ),
      class = c("tbl_df", "tbl", "data.frame"),
      row.names = c(NA, -9L)
    )
  )
})

test_that("data frame dimensions as expected when both `DataSet` and `SimulationResults` provided", {
  myCombDat <- DataCombined$new()
  myCombDat$addSimulationResults(
    simResults,
    quantitiesOrPaths = c(
      "Organism|Lumen|Stomach|Dapagliflozin|Gastric retention",
      "Organism|Lumen|Stomach|Dapagliflozin|Gastric emptying",
      "Organism|Lumen|Stomach|Metformin|Gastric retention"
    ),
    names = list("x", "y", "z")
  )

  myCombDat$addDataSets(
    dataSet,
    names = list("a", NULL, "b", NULL, "c", NULL)
  )

  df <- myCombDat$toDataFrame()
  expect_equal(nrow(df), 830L)
})

test_that("data frame column names are as expected when both `DataSet` and `SimulationResults` provided", {
  myCombDat <- DataCombined$new()
  myCombDat$addSimulationResults(
    simResults,
    quantitiesOrPaths = c(
      "Organism|Lumen|Stomach|Dapagliflozin|Gastric retention",
      "Organism|Lumen|Stomach|Dapagliflozin|Gastric emptying",
      "Organism|Lumen|Stomach|Metformin|Gastric retention"
    ),
    names = list("x", "y", "z")
  )

  myCombDat$addDataSets(
    dataSet,
    names = list("a", NULL, "b", NULL, "c", NULL)
  )

  df <- myCombDat$toDataFrame()

  expect_equal(
    sort(names(df)),
    sort(c(
      "name",
      "group",
      "dataType",
      "xValues",
      "xUnit",
      "xDimension",
      "yValues",
      "yUnit",
      "yDimension",
      "yErrorValues",
      "yErrorType",
      "yErrorUnit",
      "IndividualId",
      "molWeight",
      "lloq",
      "Sheet",
      "Group Id"
    ))
  )
})

test_that("data frames for selected output paths match with outputs from `simulationResultsToDataFrame()` function", {
  myCombDat <- DataCombined$new()
  myCombDat$addSimulationResults(
    simResults,
    quantitiesOrPaths = c(
      "Organism|Lumen|Stomach|Dapagliflozin|Gastric retention",
      "Organism|Lumen|Stomach|Dapagliflozin|Gastric emptying",
      "Organism|Lumen|Stomach|Metformin|Gastric retention"
    ),
    names = list("x", "y", "z")
  )

  myCombDat$addDataSets(
    dataSet,
    names = list("a", NULL, "b", NULL, "c", NULL)
  )

  df <- myCombDat$toDataFrame()

  expect_equal(
    dplyr::filter(df, name == "x")$yValues,
    simulationResultsToDataFrame(
      simResults,
      quantitiesOrPaths = "Organism|Lumen|Stomach|Dapagliflozin|Gastric retention"
    )$simulationValues
  )

  expect_equal(
    dplyr::filter(df, name == "y")$yValues,
    simulationResultsToDataFrame(
      simResults,
      quantitiesOrPaths = "Organism|Lumen|Stomach|Dapagliflozin|Gastric emptying"
    )$simulationValues
  )

  expect_equal(
    dplyr::filter(df, name == "z")$yValues,
    simulationResultsToDataFrame(
      simResults,
      quantitiesOrPaths = "Organism|Lumen|Stomach|Metformin|Gastric retention"
    )$simulationValues
  )
})

# order and renaming -----------------------------

test_that("renaming only a single dataset works", {
  myCombDat <- DataCombined$new()
  myCombDat$addSimulationResults(
    simResults,
    quantitiesOrPaths = c(
      "Organism|Lumen|Stomach|Dapagliflozin|Gastric retention"
    ),
    names = list("m")
  )
  expect_equal(myCombDat$names, "m")
})

test_that("Method chaining works", {
  myCombDat <- DataCombined$new()

  expect_no_error(myCombDat$addDataSets(dataSet[[1]])$addSimulationResults(
    simResults
  )$toDataFrame())
})

test_that("data order with or without `names` argument should be same", {
  myCombDat <- DataCombined$new()
  myCombDat2 <- DataCombined$new()

  # add a list of datasets without names in the container list
  # don't specify names argument for one, while do for the other
  myCombDat$addDataSets(list(dataSet[[1]], dataSet[[2]], dataSet[[3]]))
  myCombDat2$addDataSets(
    list(dataSet[[1]], dataSet[[2]], dataSet[[3]]),
    names = list("x", "y", NULL)
  )

  # extract data frames
  df1 <- myCombDat$toDataFrame()
  df2 <- myCombDat2$toDataFrame()

  # except for names column, everything should look the same across two objects
  expect_equal(nrow(df1), nrow(df2))
  expect_equal(length(df1), length(df2))
  expect_equal(df1$xValues, df2$xValues)
  expect_equal(df1$yValues, df2$yValues)

  expect_equal(
    sort(as.character(unique(df1$name))),
    sort(c(
      "Stevens_2012_placebo.Placebo_proximal",
      "Stevens_2012_placebo.Placebo_total",
      "Stevens_2012_placebo.Sita_total"
    ))
  )

  expect_equal(
    sort(as.character(unique(df2$name))),
    sort(c("Stevens_2012_placebo.Placebo_proximal", "x", "y"))
  )
})

test_that("data frame should be same when objects are entered either as a list or a vector", {
  myCombDat1 <- DataCombined$new()
  myCombDat2 <- DataCombined$new()

  # both of these should provide the same result
  myCombDat1$addDataSets(list(dataSet[[1]], dataSet[[2]], dataSet[[3]]))
  myCombDat2$addDataSets(c(dataSet[[1]], dataSet[[2]], dataSet[[3]]))

  expect_equal(myCombDat1$toDataFrame(), myCombDat2$toDataFrame())
})

test_that("it shows a warning when a dataset is added with the same name as a dataset already present in dataCombined", {
  ds <- DataSet$new(name = "test")
  ds$setValues(1, 1)

  dc <- DataCombined$new()
  dc$addDataSets(ds)
  expect_warning(dc$addDataSets(ds))

  dc$addSimulationResults(simResults)
  expect_warning(dc$addSimulationResults(simResults))
})

test_that("The warning can be explicitly silenced", {
  dc <- DataCombined$new()
  dc$addSimulationResults(simResults)
  expect_no_warning(dc$addSimulationResults(simResults, silent = TRUE))
})

# data transformations --------------------------

test_that("data transformations don't work with arguments of wrong length", {
  myCombDat <- DataCombined$new()
  myCombDat$addSimulationResults(simResults)
  myCombDat$addDataSets(dataSet)

  expect_error(
    myCombDat$setDataTransformations(
      forNames = list(
        "Organism|Lumen|Stomach|Dapagliflozin|Gastric retention",
        "Organism|Lumen|Stomach|Dapagliflozin|Gastric emptying",
        "Stevens_2012_placebo.Sita_proximal",
        "Stevens_2012_placebo.Placebo_distal"
      ),
      xOffsets = list(2, 4, 5, 5, 6)
    )
  )

  expect_error(
    myCombDat$setDataTransformations(
      forNames = list(
        "Organism|Lumen|Stomach|Dapagliflozin|Gastric retention",
        "Organism|Lumen|Stomach|Dapagliflozin|Gastric emptying"
      ),
      yOffsets = list(2, 5, 6)
    )
  )

  expect_error(
    myCombDat$setDataTransformations(
      forNames = list(
        "Organism|Lumen|Stomach|Dapagliflozin|Gastric retention",
        "Organism|Lumen|Stomach|Dapagliflozin|Gastric emptying"
      ),
      xOffsets = list(2, 3, 6, 7),
      xScaleFactors = list(1.5, 2.4),
      yOffsets = c(4, 7, 8),
      yScaleFactors = c(1.1)
    )
  )
})

test_that("data transformations don't work with arguments of wrong type", {
  myCombDat <- DataCombined$new()
  myCombDat$addSimulationResults(simResults)
  myCombDat$addDataSets(dataSet)

  expect_error(
    myCombDat$setDataTransformations(
      forNames = list(
        "Organism|Lumen|Stomach|Dapagliflozin|Gastric retention",
        "Organism|Lumen|Stomach|Dapagliflozin|Gastric emptying"
      ),
      xOffsets = list("0", "1")
    )
  )

  expect_error(myCombDat$setDataTransformations(
    forNames = 2,
    xOffsets = "2"
  ))

  expect_error(myCombDat$setDataTransformations(
    forNames = c(
      "Organism|Lumen|Stomach|Dapagliflozin|Gastric retention",
      "Stevens_2012_placebo.Sita_proximal"
    ),
    xOffsets = c("2", 3),
    xScaleFactors = c("1.5", 2.4)
  ))
})

# useful across many tests
names_ls <- list(
  "Organism|Lumen|Stomach|Dapagliflozin|Gastric retention",
  "Organism|Lumen|Stomach|Dapagliflozin|Gastric emptying",
  "Stevens_2012_placebo.Sita_proximal",
  "Stevens_2012_placebo.Placebo_distal"
)

test_that("transformed values are equal to raw values times scale factor plus offsets - same transformations for each dataset", {
  myCombDat <- DataCombined$new()
  myCombDat$addSimulationResults(simResults)
  myCombDat$addDataSets(dataSet)

  # original data frame
  dfOriginal <- myCombDat$toDataFrame()
  dfOriginal <- dplyr::filter(dfOriginal, name %in% names_ls)

  myCombDat$setDataTransformations(
    forNames = names_ls,
    xOffsets = 2,
    yOffsets = 4,
    xScaleFactors = 1.5,
    yScaleFactors = 2.5
  )

  # check data transformations are correctly saved inside the object
  expect_equal(
    myCombDat$dataTransformations,
    structure(
      list(
        name = c(
          "Organism|Lumen|Stomach|Dapagliflozin|Gastric emptying",
          "Organism|Lumen|Stomach|Dapagliflozin|Gastric retention",
          "Organism|Lumen|Stomach|Metformin|Gastric retention distal",
          "Organism|Lumen|Stomach|Metformin|Gastric retention proximal",
          "Organism|Lumen|Stomach|Metformin|Gastric retention",
          "Stevens_2012_placebo.Placebo_total",
          "Stevens_2012_placebo.Sita_total",
          "Stevens_2012_placebo.Placebo_proximal",
          "Stevens_2012_placebo.Sita_proximal",
          "Stevens_2012_placebo.Placebo_distal",
          "Stevens_2012_placebo.Sita_dist"
        ),
        xOffsets = c(2, 2, 0, 0, 0, 0, 0, 0, 2, 2, 0),
        yOffsets = c(4, 4, 0, 0, 0, 0, 0, 0, 4, 4, 0),
        xScaleFactors = c(1.5, 1.5, 1, 1, 1, 1, 1, 1, 1.5, 1.5, 1),
        yScaleFactors = c(2.5, 2.5, 1, 1, 1, 1, 1, 1, 2.5, 2.5, 1)
      ),
      class = c("tbl_df", "tbl", "data.frame"),
      row.names = c(NA, -11L)
    )
  )

  dfTransformed <- myCombDat$toDataFrame()
  dfTransformed <- dplyr::filter(dfTransformed, name %in% names_ls)

  expect_equal(dfTransformed$xValues, (dfOriginal$xValues + 2) * 1.5)
  expect_equal(dfTransformed$yValues, (dfOriginal$yValues + 4) * 2.5)
  expect_equal(dfTransformed$yErrorValues, dfOriginal$yErrorValues * 2.5)
})

test_that("correct transformations with negative scale factors", {
  myCombDat <- DataCombined$new()
  myCombDat$addDataSets(dataSet[[1]])

  # original data frame
  dfOriginal <- myCombDat$toDataFrame()

  # First test with positive scale factor
  myCombDat$setDataTransformations(
    forNames = dataSet[[1]]$name,
    yScaleFactors = 2.5
  )
  expect_equal(myCombDat$dataTransformations$yScaleFactors, 2.5)

  dfTransformed <- myCombDat$toDataFrame()
  expect_equal(dfTransformed$yValues, dfOriginal$yValues * 2.5)
  expect_equal(dfTransformed$yErrorValues, dfOriginal$yErrorValues * 2.5)

  # Now with negative scale factor
  myCombDat$setDataTransformations(
    forNames = dataSet[[1]]$name,
    yScaleFactors = -2.5
  )
  expect_equal(myCombDat$dataTransformations$yScaleFactors, -2.5)

  dfTransformed <- myCombDat$toDataFrame()
  expect_equal(dfTransformed$yValues, dfOriginal$yValues * -2.5)
  expect_equal(dfTransformed$yErrorValues, dfOriginal$yErrorValues * 2.5)
})

test_that("transformed values are equal to raw values times scale factor plus offsets - different transformations for each dataset", {
  myCombDat <- DataCombined$new()
  myCombDat$addDataSets(dataSet)
  myCombDat$addSimulationResults(simResults)

  dfOriginal <- myCombDat$toDataFrame()
  dfOriginal <- dplyr::filter(dfOriginal, name %in% names_ls)

  myCombDat$setDataTransformations(
    forNames = list(
      "Organism|Lumen|Stomach|Dapagliflozin|Gastric retention",
      "Stevens_2012_placebo.Sita_proximal"
    ),
    # mix atomic vectors and lists to make sure that both work
    xOffsets = list(2, 3),
    yOffsets = c(4, 7),
    xScaleFactors = list(1.5, 2.4),
    yScaleFactors = c(1.1, 2.2)
  )

  # check the transformation values are accurately saved
  expect_equal(
    myCombDat$dataTransformations,
    structure(
      list(
        name = c(
          "Stevens_2012_placebo.Placebo_total",
          "Stevens_2012_placebo.Sita_total",
          "Stevens_2012_placebo.Placebo_proximal",
          "Stevens_2012_placebo.Sita_proximal",
          "Stevens_2012_placebo.Placebo_distal",
          "Stevens_2012_placebo.Sita_dist",
          "Organism|Lumen|Stomach|Dapagliflozin|Gastric emptying",
          "Organism|Lumen|Stomach|Dapagliflozin|Gastric retention",
          "Organism|Lumen|Stomach|Metformin|Gastric retention distal",
          "Organism|Lumen|Stomach|Metformin|Gastric retention proximal",
          "Organism|Lumen|Stomach|Metformin|Gastric retention"
        ),
        xOffsets = c(0, 0, 0, 3, 0, 0, 0, 2, 0, 0, 0),
        yOffsets = c(0, 0, 0, 7, 0, 0, 0, 4, 0, 0, 0),
        xScaleFactors = c(1, 1, 1, 2.4, 1, 1, 1, 1.5, 1, 1, 1),
        yScaleFactors = c(1, 1, 1, 2.2, 1, 1, 1, 1.1, 1, 1, 1)
      ),
      class = c("tbl_df", "tbl", "data.frame"),
      row.names = c(NA, -11L)
    )
  )

  df <- myCombDat$toDataFrame()

  # first level
  expect_equal(
    dplyr::filter(
      df,
      name == "Organism|Lumen|Stomach|Dapagliflozin|Gastric retention"
    )$xValues,
    (dplyr::filter(
      dfOriginal,
      name == "Organism|Lumen|Stomach|Dapagliflozin|Gastric retention"
    )$xValues +
      2) *
      1.5
  )
  expect_equal(
    dplyr::filter(
      df,
      name == "Organism|Lumen|Stomach|Dapagliflozin|Gastric retention"
    )$yValues,
    (dplyr::filter(
      dfOriginal,
      name == "Organism|Lumen|Stomach|Dapagliflozin|Gastric retention"
    )$yValues +
      4) *
      1.1
  )
  expect_equal(
    dplyr::filter(
      df,
      name == "Organism|Lumen|Stomach|Dapagliflozin|Gastric retention"
    )$yErrorValues,
    dplyr::filter(
      dfOriginal,
      name == "Organism|Lumen|Stomach|Dapagliflozin|Gastric retention"
    )$yErrorValues *
      1.1
  )

  # second level
  expect_equal(
    dplyr::filter(df, name == "Stevens_2012_placebo.Sita_proximal")$xValues,
    (dplyr::filter(
      dfOriginal,
      name == "Stevens_2012_placebo.Sita_proximal"
    )$xValues +
      3) *
      2.4
  )
  expect_equal(
    dplyr::filter(df, name == "Stevens_2012_placebo.Sita_proximal")$yValues,
    (dplyr::filter(
      dfOriginal,
      name == "Stevens_2012_placebo.Sita_proximal"
    )$yValues +
      7) *
      2.2
  )
  expect_equal(
    dplyr::filter(
      df,
      name == "Stevens_2012_placebo.Sita_proximal"
    )$yErrorValues,
    dplyr::filter(
      dfOriginal,
      name == "Stevens_2012_placebo.Sita_proximal"
    )$yErrorValues *
      2.2
  )
})

test_that("each call to set transformations resets previous parameters for the same dataset", {
  myCombDat3 <- DataCombined$new()

  myCombDat3$addSimulationResults(
    simResults,
    quantitiesOrPaths = "Organism|Lumen|Stomach|Dapagliflozin|Gastric emptying"
  )
  myCombDat3$setDataTransformations()
  df1 <- myCombDat3$dataTransformations
  dfDat1 <- myCombDat3$toDataFrame()

  myCombDat3$setDataTransformations(xOffsets = 3, yScaleFactors = 4)
  df2 <- myCombDat3$dataTransformations
  dfDat2 <- myCombDat3$toDataFrame()

  myCombDat3$setDataTransformations(reset = TRUE)
  df3 <- myCombDat3$dataTransformations
  dfDat3 <- myCombDat3$toDataFrame()

  # transformation values used
  expect_equal(df1, df3)
  expect_equal(df2$xOffsets, 3)
  expect_equal(df2$yScaleFactors, 4)

  # making sure transformations actually change values as expected
  expect_equal(dfDat1, dfDat3)
  expect_equal(dfDat1$xValues + 3, dfDat2$xValues)
  expect_equal(dfDat1$yValues * 4, dfDat2$yValues)
})

test_that("Calls to set transformations with only part of the parameters do not reset other transformations", {
  myDC <- DataCombined$new()
  obsData <- loadDataSetFromPKML(system.file(
    "extdata",
    "ObsDataAciclovir_1.pkml",
    package = "ospsuite"
  ))
  myDC$addDataSets(obsData)
  myDC$setDataTransformations(xOffsets = 1)
  myDC$setDataTransformations(yOffsets = 2)

  expect_equal(myDC$dataTransformations$xOffsets, 1)
  expect_equal(myDC$dataTransformations$yOffsets, 2)
})

test_that("messy inputs (with special constants) for data transformations don't cause any problems", {
  myCombDat <- DataCombined$new()
  myCombDat$addDataSets(dataSet)
  myCombDat$addSimulationResults(simResults)

  myCombDat$setDataTransformations(
    forNames = names_ls,
    xOffsets = list(NULL, NA, NA_character_, NULL),
    yOffsets = c(NA, NA_real_, NA, NaN),
    xScaleFactors = c(NA, NA_integer_, NA, NA),
    yScaleFactors = list(NULL, NaN, NA, NULL)
  )

  expect_equal(
    myCombDat$dataTransformations,
    structure(
      list(
        name = c(
          "Stevens_2012_placebo.Placebo_total",
          "Stevens_2012_placebo.Sita_total",
          "Stevens_2012_placebo.Placebo_proximal",
          "Stevens_2012_placebo.Sita_proximal",
          "Stevens_2012_placebo.Placebo_distal",
          "Stevens_2012_placebo.Sita_dist",
          "Organism|Lumen|Stomach|Dapagliflozin|Gastric emptying",
          "Organism|Lumen|Stomach|Dapagliflozin|Gastric retention",
          "Organism|Lumen|Stomach|Metformin|Gastric retention distal",
          "Organism|Lumen|Stomach|Metformin|Gastric retention proximal",
          "Organism|Lumen|Stomach|Metformin|Gastric retention"
        ),
        xOffsets = c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
        yOffsets = c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
        xScaleFactors = c(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1),
        yScaleFactors = c(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1)
      ),
      class = c("tbl_df", "tbl", "data.frame"),
      row.names = c(NA, -11L)
    )
  )
})


test_that("data grouping works as expected - multiple datasets", {
  myCombDat <- DataCombined$new()

  myCombDat$addSimulationResults(simResults)
  myCombDat$setGroups(
    names = list(
      "Organism|Lumen|Stomach|Metformin|Gastric retention distal",
      "Organism|Lumen|Stomach|Metformin|Gastric retention proximal",
      "Organism|Lumen|Stomach|Metformin|Gastric retention"
    ),
    groups = list("distal", "proximal", "total")
  )

  myCombDat$addDataSets(dataSet)
  myCombDat$setGroups(
    names = list(
      "Stevens_2012_placebo.Placebo_total",
      "Stevens_2012_placebo.Sita_total",
      "Stevens_2012_placebo.Placebo_proximal",
      "Stevens_2012_placebo.Sita_proximal",
      "Stevens_2012_placebo.Placebo_distal",
      "Stevens_2012_placebo.Sita_dist"
    ),
    groups = list("total", "total", "proximal", "proximal", "distal", "distal")
  )

  # check mapping
  dfMap <- myCombDat$groupMap

  expect_equal(dim(dfMap), c(11L, 3L))

  expect_equal(
    dplyr::filter(dfMap, group == "distal", dataType == "simulated")$name,
    "Organism|Lumen|Stomach|Metformin|Gastric retention distal"
  )

  expect_equal(
    dplyr::filter(dfMap, group == "distal", dataType == "observed")$name,
    c("Stevens_2012_placebo.Placebo_distal", "Stevens_2012_placebo.Sita_dist")
  )

  expect_equal(
    dplyr::filter(dfMap, group == "proximal", dataType == "simulated")$name,
    "Organism|Lumen|Stomach|Metformin|Gastric retention proximal"
  )

  expect_equal(
    dplyr::filter(dfMap, group == "proximal", dataType == "observed")$name,
    c(
      "Stevens_2012_placebo.Placebo_proximal",
      "Stevens_2012_placebo.Sita_proximal"
    )
  )

  expect_equal(
    dplyr::filter(dfMap, group == "total", dataType == "simulated")$name,
    "Organism|Lumen|Stomach|Metformin|Gastric retention"
  )

  expect_equal(
    dplyr::filter(dfMap, group == "total", dataType == "observed")$name,
    c("Stevens_2012_placebo.Placebo_total", "Stevens_2012_placebo.Sita_total")
  )
})

test_that("data grouping works as expected - single dataset", {
  myCombDat <- DataCombined$new()
  myCombDat$addDataSets(dataSet[[1]])
  myCombDat$setGroups(
    names = list("Stevens_2012_placebo.Placebo_total"),
    groups = list("x")
  )

  expect_equal(myCombDat$groupMap$group[[1]], "x")
  expect_equal(
    myCombDat$groupMap$name[[1]],
    "Stevens_2012_placebo.Placebo_total"
  )
})


test_that("sequential update when first and second datasets have same names and same data - data frames and bindings should be identical", {
  myCombDat <- DataCombined$new()

  # first run

  myCombDat$addDataSets(dataSet)
  myCombDat$setGroups(
    names = list(
      "Stevens_2012_placebo.Placebo_total",
      "Stevens_2012_placebo.Sita_total",
      "Stevens_2012_placebo.Placebo_proximal",
      "Stevens_2012_placebo.Sita_proximal",
      "Stevens_2012_placebo.Placebo_distal",
      "Stevens_2012_placebo.Sita_dist"
    ),
    groups = list("total", "total", "proximal", "proximal", "distal", "distal")
  )

  myCombDat$addSimulationResults(simResults)
  myCombDat$setGroups(
    names = list(
      "Organism|Lumen|Stomach|Metformin|Gastric retention distal",
      "Organism|Lumen|Stomach|Metformin|Gastric retention proximal",
      "Organism|Lumen|Stomach|Metformin|Gastric retention"
    ),
    groups = list("distal", "proximal", "total")
  )

  df1 <- myCombDat$toDataFrame()

  # second run but with different grouping
  expect_warning(myCombDat$addSimulationResults(simResults))
  myCombDat$setGroups(
    names = list(
      "Organism|Lumen|Stomach|Dapagliflozin|Gastric emptying",
      "Organism|Lumen|Stomach|Dapagliflozin|Gastric retention"
    ),
    groups = list("Dapagliflozin - emptying", "Dapagliflozin - retention")
  )

  expect_warning(myCombDat$addDataSets(dataSet))
  myCombDat$setGroups(
    names = list(
      "Stevens_2012_placebo.Placebo_distal",
      "Stevens_2012_placebo.Sita_dist"
    ),
    groups = list("distal", "distal")
  )

  df2 <- myCombDat$toDataFrame()

  # should be the same number of rows and columns
  expect_equal(nrow(df2), nrow(df1))
  expect_equal(length(df2), length(df1))

  # but groupings should be different
  expect_equal(
    unique(df1$group),
    factor(
      c("total", "proximal", "distal", NA_character_),
      levels = c("total", "proximal", "distal")
    )
  )

  expect_equal(
    unique(df2$group),
    factor(
      c(
        "Dapagliflozin - emptying",
        "Dapagliflozin - retention",
        NA_character_,
        "distal"
      ),
      levels = c(
        "Dapagliflozin - emptying",
        "Dapagliflozin - retention",
        "distal"
      )
    )
  )

  # extract group map into a data frame
  dfMap <- myCombDat$groupMap

  expect_equal(dim(dfMap), c(11L, 3L))

  expect_equal(
    dplyr::filter(dfMap, group == "Dapagliflozin - emptying")$name,
    "Organism|Lumen|Stomach|Dapagliflozin|Gastric emptying"
  )

  expect_equal(
    dplyr::filter(dfMap, group == "Dapagliflozin - retention")$name,
    "Organism|Lumen|Stomach|Dapagliflozin|Gastric retention"
  )

  expect_equal(
    dplyr::filter(dfMap, group == "distal")$name,
    c(
      "Stevens_2012_placebo.Placebo_distal",
      "Stevens_2012_placebo.Sita_dist"
    )
  )

  expect_equal(
    sort(dplyr::filter(dfMap, is.na(group))$name),
    sort(c(
      "Organism|Lumen|Stomach|Metformin|Gastric retention",
      "Organism|Lumen|Stomach|Metformin|Gastric retention distal",
      "Organism|Lumen|Stomach|Metformin|Gastric retention proximal",
      "Stevens_2012_placebo.Placebo_proximal",
      "Stevens_2012_placebo.Placebo_total",
      "Stevens_2012_placebo.Sita_proximal",
      "Stevens_2012_placebo.Sita_total"
    ))
  )
})

test_that("sequential update when first and second datasets have same names but different data - second should replace first", {
  myCombDat <- DataCombined$new()

  myCombDat$addDataSets(dataSet)

  # let's focus only on the datasets which are going to be duplicated in the next update
  df1 <- myCombDat$toDataFrame()
  df1Filter <- dplyr::filter(
    df1,
    name %in%
      c("Stevens_2012_placebo.Placebo_total", "Stevens_2012_placebo.Sita_total")
  )

  # update object with another `DataSet` object which has common datasets
  expect_warning(myCombDat$addDataSets(dataSet2))

  df2 <- myCombDat$toDataFrame()
  df2Filter <- dplyr::filter(
    df2,
    name %in%
      c("Stevens_2012_placebo.Placebo_total", "Stevens_2012_placebo.Sita_total")
  )

  # check dimensions and values

  # they should be different since the new dataset that replaces the old one has
  # deliberately different values and rows
  expect_equal(dim(df1), c(77L, 16L))
  expect_equal(dim(df2), c(76L, 16L))
  expect_equal(dim(df1Filter), c(25L, 16L))
  expect_equal(dim(df2Filter), c(24L, 16L))

  expect_equal(
    head(df1Filter$xValues),
    c(
      0,
      13.1722688674927,
      29.4033622741699,
      44.6470603942871,
      73.079833984375,
      88.2731094360352
    )
  )

  expect_equal(
    head(df2Filter$xValues),
    c(
      0,
      14.218487739563,
      27.4033622741699,
      43.6344528198242,
      57.8403358459473,
      74.0672302246094
    )
  )
})

# `Population` objects -----------------------------

test_that("data frame is as expected when `Population` objects are used", {
  # Load simulation
  sim <- loadSimulation(
    aciclovirSimulationPath,
    loadFromCache = TRUE,
    addToCache = TRUE
  )

  populationResults <- importResultsFromCSV(
    simulation = sim,
    filePaths = getTestDataFilePath("SimResults_pop.csv")
  )

  myDataComb <- DataCombined$new()
  myDataComb$addSimulationResults(
    populationResults,
    individualIds = c(1, 8, 10, 44)
  )
  df <- myDataComb$toDataFrame()

  expect_equal(nrow(df), 3928L)

  expect_equal(min(df$IndividualId), 1)
  expect_equal(max(df$IndividualId), 44)
  expect_equal(unique(df$yUnit), .encodeUnit("µmol/l"))
  expect_equal(unique(df$yDimension), "Concentration (molar)")
  expect_equal(unique(df$xUnit), "min")
})

# `DataSet` with metadata -----------------------------

myDataSet <- dataSet$Stevens_2012_placebo.Placebo_total
myDataSet$addMetaData("Organ", "Liver")
myDataSet$addMetaData("Compartment", "Intracellular")
myDataSet$addMetaData("Species", "Human")

test_that("data frame dimensions are as expected when `DataSet` with metadata is provided", {
  myCombDat <- DataCombined$new()
  myCombDat$addDataSets(myDataSet)
  df <- myCombDat$toDataFrame()

  expect_equal(nrow(df), 12L)
})

test_that("data frame column names are as expected when `DataSet` with metadata is provided", {
  myCombDat <- DataCombined$new()
  myCombDat$addDataSets(myDataSet)
  df <- myCombDat$toDataFrame()

  expect_equal(
    sort(names(df)),
    sort(c(
      "name",
      "group",
      "dataType",
      "xValues",
      "xUnit",
      "xDimension",
      "yValues",
      "yUnit",
      "yDimension",
      "yErrorValues",
      "yErrorType",
      "yErrorUnit",
      "molWeight",
      "lloq",
      "Sheet",
      "Group Id",
      "Organ",
      "Compartment",
      "Species"
    ))
  )
})

test_that("data frame metadata column entries are as expected when `DataSet` with metadata is provided", {
  myCombDat <- DataCombined$new()
  myCombDat$addDataSets(myDataSet)
  df <- myCombDat$toDataFrame()

  expect_equal(unique(df$Organ), "Liver")
  expect_equal(unique(df$Compartment), "Intracellular")
  expect_equal(unique(df$Species), "Human")
})

# Scalar groups specification -----------------------------

dataSet1 <- DataSet$new(name = "Dataset1")
dataSet1$setValues(1, 1)
dataSet1$yDimension <- ospDimensions$`Concentration (molar)`
dataSet1$molWeight <- 1

dataSet2 <- DataSet$new(name = "Dataset2")
dataSet2$setValues(2, 2)
dataSet2$yDimension <- ospDimensions$`Concentration (mass)`
dataSet2$molWeight <- 1

dataSet3 <- DataSet$new(name = "Dataset3")
dataSet3$setValues(1, 3)
dataSet3$yDimension <- ospDimensions$`Concentration (mass)`
dataSet3$molWeight <- 1

test_that("scalar argument to `groups` works as expected", {
  myCombDatWithOnlyDataSets <- DataCombined$new()
  myCombDatWithOnlyDataSets$addDataSets(
    c(dataSet1, dataSet2, dataSet3),
    groups = "myGroup"
  )

  expect_equal(
    unique(myCombDatWithOnlyDataSets$groupMap$group),
    "myGroup"
  )
})


test_that("scalar argument in a list to `groups` works as expected", {
  myCombDatWithOnlyDataSets2 <- DataCombined$new()
  myCombDatWithOnlyDataSets2$addDataSets(
    c(dataSet1, dataSet2, dataSet3),
    groups = list("myGroup")
  )

  expect_equal(
    unique(myCombDatWithOnlyDataSets2$groupMap$group),
    "myGroup"
  )
})

test_that("It can add a data set without error type after adding a data set with error", {
  dataCombined <- DataCombined$new()
  ds <- DataSet$new(name = "withError")
  ds$setValues(
    xValues = c(1, 2),
    yValues = c(1, 2),
    yErrorValues = c(1, 2)
  )
  dataCombined$addDataSets(ds)

  ds <- DataSet$new(name = "withoutError")
  ds$setValues(
    xValues = c(1, 2),
    yValues = c(1, 2)
  )
  dataCombined$addDataSets(ds)

  expect_warning(dataCombined$addDataSets(ds))
})

test_that("It can print data combined", {
  dataCombined <- DataCombined$new()
  ds <- DataSet$new(name = "withError")
  ds$setValues(
    xValues = c(1, 2),
    yValues = c(1, 2),
    yErrorValues = c(1, 2)
  )
  dataCombined$addDataSets(ds, groups = "firstGroup")

  ds <- DataSet$new(name = "withoutError")
  ds$setValues(
    xValues = c(1, 2),
    yValues = c(1, 2)
  )
  dataCombined$addDataSets(ds)

  expect_snapshot(print(dataCombined))
})
