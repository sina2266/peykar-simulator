# data to be used ---------------------------------------

# load the simulation
sim <- loadTestSimulation("simple", loadFromCache = TRUE, addToCache = TRUE)
simResults <- importResultsFromCSV(
  simulation = sim,
  filePaths = getTestDataFilePath("Stevens_2012_placebo_indiv_results.csv")
)

# import observed data (will return a list of `DataSet` objects)
dataSet <- loadDataSetsFromExcel(
  xlsFilePath = getTestDataFilePath("CompiledDataSetStevens2012.xlsx"),
  importerConfiguration = loadDataImporterConfiguration(getTestDataFilePath(
    "ImporterConfiguration.xml"
  ))
)

aciclovirSimulation <- loadSimulation(
  aciclovirSimulationPath,
  loadFromCache = TRUE,
  addToCache = TRUE
)

aciclovirSimResults <- runSimulations(aciclovirSimulation)[[1]]
aciclovirSimData <- withr::with_tempdir({
  df <- dplyr::tibble(
    IndividualId = c(0, 0, 0),
    `Time [min]` = c(0, 2, 4),
    `Organism|PeripheralVenousBlood|Aciclovir|Plasma (Peripheral Venous Blood) [µmol/l]` = c(
      0.5,
      4,
      8
    )
  )
  readr::write_csv(df, "SimResults.csv")
  importResultsFromCSV(aciclovirSimulation, "SimResults.csv")
})
# observed data
obsData <- lapply(
  c(
    "ObsDataAciclovir_1.pkml",
    "ObsDataAciclovir_2.pkml",
    "ObsDataAciclovir_3.pkml"
  ),
  function(x) {
    loadDataSetFromPKML(system.file("extdata", x, package = "ospsuite"))
  }
)
names(obsData) <- lapply(obsData, function(x) x$name)

# create a new instance and add datasets
myCombDat <- DataCombined$new()
myCombDat$addDataSets(dataSet[c(1, 3, 5)])
myCombDat$addSimulationResults(
  simResults,
  quantitiesOrPaths = c(
    "Organism|Lumen|Stomach|Metformin|Gastric retention",
    "Organism|Lumen|Stomach|Metformin|Gastric retention distal",
    "Organism|Lumen|Stomach|Metformin|Gastric retention proximal"
  )
)

myCombDat$setGroups(
  names = c(
    "Organism|Lumen|Stomach|Metformin|Gastric retention",
    "Organism|Lumen|Stomach|Metformin|Gastric retention distal",
    "Organism|Lumen|Stomach|Metformin|Gastric retention proximal",
    "Stevens_2012_placebo.Placebo_total",
    "Stevens_2012_placebo.Placebo_distal",
    "Stevens_2012_placebo.Placebo_proximal"
  ),
  groups = c(
    "Solid total",
    "Solid distal",
    "Solid proximal",
    "Solid total",
    "Solid distal",
    "Solid proximal"
  )
)

# plot tests --------------

test_that("It creates default plots as expected", {
  set.seed(123)
  vdiffr::expect_doppelganger(
    title = "defaults",
    fig = plotPredictedVsObserved(myCombDat, xyScale = "linear")
  )
})

test_that("It creates default plots as expected without any identity or foldDistance line", {
  set.seed(123)
  vdiffr::expect_doppelganger(
    title = "defaults without lines",
    fig = plotPredictedVsObserved(
      myCombDat,
      comparisonLineVector = NULL,
      xyScale = "linear"
    )
  )
})

test_that("It creates default plots as expected with single fold distance line", {
  set.seed(123)
  # use suppressWarnings instaed of expect_warnings. Main focus is on the plot display
  suppressWarnings(
    vdiffr::expect_doppelganger(
      title = "default 1 fold dist",
      fig = plotPredictedVsObserved(
        myCombDat,
        comparisonLineVector = unname(
          ospsuite.plots::getFoldDistanceList(
            folds = 2
          )
        )
      )
    )
  )
})

test_that("It creates default plots as expected with multiple fold distance lines", {
  set.seed(123)
  # use suppressWarnings instaed of expect_warnings. Main focus is on the plot display
  suppressWarnings(vdiffr::expect_doppelganger(
    title = "default 3 fold dist",
    fig = plotPredictedVsObserved(
      myCombDat,
      comparisonLineVector = unname(
        ospsuite.plots::getFoldDistanceList(
          folds = c(2, 4, 6)
        )
      )
    )
  ))
})

test_that("It produces expected plot for Aciclovir data", {
  outputPaths <- "Organism|PeripheralVenousBlood|Aciclovir|Plasma (Peripheral Venous Blood)"
  myDataCombined <- DataCombined$new()

  # Add simulated results
  myDataCombined$addSimulationResults(
    simulationResults = aciclovirSimResults,
    quantitiesOrPaths = outputPaths,
    groups = "Aciclovir PVB"
  )

  # Add observed data set
  myDataCombined$addDataSets(obsData$`Vergin 1995.Iv`, groups = "Aciclovir PVB")

  set.seed(123)
  vdiffr::expect_doppelganger(
    title = "Aciclovir",
    fig = plotPredictedVsObserved(
      myDataCombined,
      comparisonLineVector = unname(ospsuite.plots::getFoldDistanceList(
        folds = c(2)
      ))
    )
  )
})

test_that("It returns `NULL` with warning when `DataCombined` is empty", {
  myCombDat <- DataCombined$new()

  expect_warning(
    result <- plotPredictedVsObserved(myCombDat),
    regexp = messages$plotNoDataAvailable()
  )
  expect_null(result)
})

test_that("Different symbols for data sets within one group", {
  obsData <- DataSet$new(name = "Observed")
  obsData$setValues(
    xValues = c(1, 3, 3.5, 4, 5),
    yValues = c(1.9, 6.1, 7, 8.2, 1)
  )
  obsData$xUnit <- "min"
  obsData$yDimension <- ospDimensions$`Concentration (molar)`

  myDC <- DataCombined$new()
  myDC$addSimulationResults(aciclovirSimData, groups = "myGroup")
  myDC$addDataSets(obsData, groups = "myGroup")

  # Add second obs data
  obsData2 <- DataSet$new(name = "Observed 2")
  obsData2$setValues(
    xValues = c(1, 3, 4, 4.5, 5.5),
    yValues = c(2.9, 5.1, 3, 8.2, 1)
  )
  obsData2$xUnit <- "min"
  obsData2$yDimension <- ospDimensions$`Concentration (molar)`
  myDC$addDataSets(obsData2, groups = "myGroup")

  set.seed(123)
  vdiffr::expect_doppelganger(
    title = "multiple data sets one group",
    fig = plotPredictedVsObserved(myDC)
  )
})

test_that("LLOQ is plotted", {
  obsData <- DataSet$new(name = "Observed")
  obsData$setValues(
    xValues = c(1, 3, 3.5, 4, 5),
    yValues = c(1.9, 6.1, 7, 8.2, 1)
  )
  obsData$xUnit <- "min"
  obsData$yDimension <- ospDimensions$`Concentration (molar)`
  obsData$LLOQ <- 3

  myDC <- DataCombined$new()
  myDC$addSimulationResults(aciclovirSimData, groups = "myGroup")
  myDC$addDataSets(obsData, groups = "myGroup")

  set.seed(123)
  vdiffr::expect_doppelganger(
    title = "lloq vertical",
    fig = plotPredictedVsObserved(myDC)
  )
})

# Test predictedAxis parameter ----
test_that("It swaps axes when predictedAxis is 'x'", {
  set.seed(123)
  vdiffr::expect_doppelganger(
    title = "predicted on x-axis",
    fig = plotPredictedVsObserved(
      myCombDat,
      predictedAxis = "x",
      xyScale = "linear"
    )
  )
})

# 2 y-axis dimensions ----
test_that("Plot throws error with fraction and concentration", {
  expect_error(
    plotPredictedVsObserved(manyObsSimDCWithFraction()),
    'Data contains too many'
  )
})

# xUnit / yUnit direct parameters ----
test_that("plotPredictedVsObserved produces same result as pre-converting with convertUnits", {
  plotDirect <- plotPredictedVsObserved(
    myCombDat,
    xyScale = "linear",
    yUnit = ""
  )

  expect_false(
    grepl("%", plotDirect$labels$x, fixed = TRUE),
    info = "default x-axis label should not contain '%'"
  )

  plotPreConverted <- plotPredictedVsObserved(
    convertUnits(myCombDat, yUnit = ""),
    xyScale = "linear"
  )

  expect_equal(plotDirect$data, plotPreConverted$data)
})

# showLegendPerDataset ----

test_that("showLegendPerDataset adds shape mapping for observed datasets", {
  myCombDat$setGroups(
    names = c(
      "Organism|Lumen|Stomach|Metformin|Gastric retention",
      "Organism|Lumen|Stomach|Metformin|Gastric retention distal",
      "Organism|Lumen|Stomach|Metformin|Gastric retention proximal",
      "Stevens_2012_placebo.Placebo_total",
      "Stevens_2012_placebo.Placebo_distal",
      "Stevens_2012_placebo.Placebo_proximal"
    ),
    groups = c(
      "Stevens_2012_total",
      "Stevens_2012",
      "Stevens_2012",
      "Stevens_2012_total",
      "Stevens_2012",
      "Stevens_2012"
    )
  )

  set.seed(123)
  vdiffr::expect_doppelganger(
    title = "showLegendPerDataset observed - predicted vs observed",
    fig = plotPredictedVsObserved(
      myCombDat,
      xyScale = "linear",
      showLegendPerDataset = "observed"
    )
  )

  set.seed(123)
  vdiffr::expect_doppelganger(
    title = "showLegendPerDataset none - predicted vs observed",
    fig = plotPredictedVsObserved(
      myCombDat,
      xyScale = "linear",
      showLegendPerDataset = "none"
    )
  )
})

test_that("showLegendPerDataset throws error for predictedVsObserved", {
  expect_error(
    plotPredictedVsObserved(
      myCombDat,
      xyScale = "linear",
      showLegendPerDataset = "simulated"
    ),
    "Assertion on 'showLegendPerDataset' failed"
  )
})

test_that("User mapping overrides showLegendPerDataset in predictedVsObserved", {
  myCombDat$setGroups(
    names = c(
      "Organism|Lumen|Stomach|Metformin|Gastric retention",
      "Organism|Lumen|Stomach|Metformin|Gastric retention distal",
      "Organism|Lumen|Stomach|Metformin|Gastric retention proximal",
      "Stevens_2012_placebo.Placebo_total",
      "Stevens_2012_placebo.Placebo_distal",
      "Stevens_2012_placebo.Placebo_proximal"
    ),
    groups = c(
      "Stevens_2012_total",
      "Stevens_2012",
      "Stevens_2012",
      "Stevens_2012_total",
      "Stevens_2012",
      "Stevens_2012"
    )
  )

  # User mapping overrides showLegendPerDataset
  set.seed(123)
  vdiffr::expect_doppelganger(
    title = "showLegendPerDataset overwritten by name",
    fig = plotPredictedVsObserved(
      myCombDat,
      xyScale = "linear",
      showLegendPerDataset = "observed",
      mapping = ggplot2::aes(groupby = name)
    )
  )
})
