## ----setup, include = FALSE---------------------------------------------------
library(rSharp)
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  # The examples below call into .NET. When no runtime is available (for example
  # on CRAN or R-universe build machines without .NET) the code is shown but not
  # executed, so the vignette still builds.
  eval = dotnetAvailable()
)

## -----------------------------------------------------------------------------
library(rSharp)
assembly <- loadAssembly(system.file("extdata", "rSharp.Examples.dll", package = "rSharp"))

## -----------------------------------------------------------------------------
getLoadedAssemblies()
# Check if a specific assembly is loaded
isAssemblyLoaded("rSharp.Examples")

## -----------------------------------------------------------------------------
getStaticMembers("rSharp.Examples.SampleStaticClass")

## -----------------------------------------------------------------------------
# Get the signature of the GetAString method
getStaticMemberSignature("rSharp.Examples.SampleStaticClass", "GetAString")
# Get the signature of the Add method
getStaticMemberSignature("rSharp.Examples.SampleStaticClass", "Add")

## -----------------------------------------------------------------------------
rSharp::callStatic("rSharp.Examples.SampleStaticClass", "GetAString")

## -----------------------------------------------------------------------------
rSharp::callStatic("rSharp.Examples.SampleStaticClass", "Add", as.integer(1), as.integer(2))

## -----------------------------------------------------------------------------
# Get the value of the static field
getStatic("rSharp.Examples.SampleStaticClass", "StaticString")

## -----------------------------------------------------------------------------
# Set the value of the static field
setStatic("rSharp.Examples.SampleStaticClass", "StaticString", "New value")
# Get the value of the static field
getStatic("rSharp.Examples.SampleStaticClass", "StaticString")
# Call the GetAString method
callStatic("rSharp.Examples.SampleStaticClass", "GetAString")

## -----------------------------------------------------------------------------
# Call the SampleInstanceClass method
instance <- callStatic("rSharp.Examples.SampleStaticClass", "GetInstanceObject")

# Check the class of the returned object
class(instance)

# Get the type of the object
instance$type

## -----------------------------------------------------------------------------
getConstructors("rSharp.Examples.SampleInstanceClass")

## -----------------------------------------------------------------------------
# Create a pointer to a .NET object
pointer <- newPointerFromName("rSharp.Examples.SampleInstanceClass", as.double(1), as.double(2))
# Wrap the pointer in a new NetObject
newInstance <- NetObject$new(pointer)

## -----------------------------------------------------------------------------
# Create a new instance of the SampleInstanceClass
newInstance2 <- newObjectFromName("rSharp.Examples.SampleInstanceClass", as.integer(1))

## -----------------------------------------------------------------------------
# Get the methods of the object
newInstance$getMethods()
# Get the fields of the object
newInstance$getFields()
# Get the properties of the object
newInstance$getProperties()

## -----------------------------------------------------------------------------
newInstance$getStaticFields()

## -----------------------------------------------------------------------------
# Get the value of the static field:
newInstance$get("FieldDoubleOne")
# Change the value of the static field:
newInstance$set("FieldDoubleOne", 23)
# Get the value of the static field:
newInstance$get("FieldDoubleOne")

## -----------------------------------------------------------------------------
# Call the Add method
newInstance$call("GetAString")

